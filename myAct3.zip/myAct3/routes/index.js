
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { firearm } from "../controllers/firearm.js";
const router = express.Router();

router.get("/", firearm.index);
router.get("/index", firearm.index);
router.get("/add", firearm.add);
router.post("/insert", firearm.insert);
router.post("/index", firearm.insert);
router.get("/edit/:id", firearm.edit);
router.post("/update/:id", firearm.update);
router.post("/delete/:id", firearm.delete);

// Existing device endpoints
router.get("/firearm", firearm.all);
router.post("/firearm", firearm.insert);
router.get("/firearm/:id", firearm.show);
router.put("/firearm/:id", firearm.update);
router.delete("/firearm/:id", firearm.delete);
router.get("/firearm/:id/edit", firearm.edit);
router.post("/firearm/:id/update", firearm.update);
router.post("/firearm/:id/delete", firearm.delete);

import { loginPage, registerPage, forgotPasswordPage, dashboardPage, loginUser, registerUser, logoutUser } from "../controllers/authController.js";

router.get("/login", loginPage);
router.post("/login", loginUser);
router.get("/register", registerPage);
router.post("/register", registerUser);
router.get("/forgot-password", forgotPasswordPage);
router.get("/dashboard", dashboardPage);
router.get("/logout", logoutUser);

export default router;
